

// GROUP NAMES: 
// MUHAMMAD SAFI SAHI 
// RUAN DA SILVA BARBOSA 
// RAFIGA ISMAIYLOVA




public class Convert {

    // CLASSIFYING THE FILEDS 
    private static double massResult;
    private static double tempResult;



    // TO CONVERT POUND INTO KILOGRAMS
    private static double getKilogramValue(double pound) {
        return pound / 2.2;
    }


    // TO CONVERT KILOGRAM INTO POUNDS 
    private static double getPoundValue(double kilogram) {
        return kilogram * 2.2;
    }


    // TO CONVERT CELSIUS INTO FARENHEIT
    private static double getFahrenheitValue(double celsius) {
        return (celsius * 9 / 5) + 32;
    }


    // TO CONVERT FARENHEIT INTO CELSIUS
    private static double getCelsiusValue(double fahrenheit) {
        return (fahrenheit - 32) * 5 / 9;
    }


    // Public method to convert mass
    public static double getMass(double value, int choice) {
        switch (choice) {
            case 1:
                massResult = getKilogramValue(value);
                break;
            case 2:
                massResult = getPoundValue(value);
                break;
            default:
                System.err.println("Invalid option! Please select either 1 or 2.");
                massResult = 0;
                break;
        }
        return massResult;
    }


    // Public method to convert temperature
    public static double getTemperature(double value, int choice) {
        switch (choice) {
            case 1:
                tempResult = getFahrenheitValue(value);
                break;
            case 2:
                tempResult = getCelsiusValue(value);
                break;
            default:
                System.err.println("Invalid option! Please select either 1 or 2.");
                tempResult = 0;
                break;
        }
        return tempResult;
    }
}